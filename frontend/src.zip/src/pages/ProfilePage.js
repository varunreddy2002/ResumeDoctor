function ProfilePage() {
  return <div style={{ padding: 30 }}>Welcome to your profile!</div>;
}

export default ProfilePage;
